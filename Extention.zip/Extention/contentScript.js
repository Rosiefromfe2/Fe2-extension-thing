



hi = new Audio("")
OP = true;  
lol = 0;



const musicman = document.createElement('input');
musicman.className = 'musikk';
musicman.type = "file"
musicman.id = "musikk"
musicman.accept = "audio/*"
document.getElementById("bgmStatus").appendChild(musicman);

setInterval(function()  {
  if (document.getElementById('bgmInfo').innerHTML === 'Playing BGM' & OP === true) {
    OP = false;
    hi.currentTime = 0;
     hi.play();
  }
  if (document.getElementById('bgmInfo').innerHTML === 'Playing BGM; Quietened') {
    OP = true;
  }
  if (document.getElementById('bgmInfo').innerHTML === 'Stopped BGM; Died') {
    hi.pause()
    OP = true;
  }
},10)
function save(event) {
files = event.target.files;
lol = URL.createObjectURL(files[0]);
hi.src = lol

}
document.getElementById('musikk').addEventListener('input', save);




